import 'package:flutter/material.dart';
class FitMate extends StatefulWidget {
  FitMate({Key? key}) : super(key: key);

  @override
  State<FitMate> createState() => _FitMateState();
}
class _FitMateState extends State<FitMate> {
  @override
  Widget build(BuildContext context) {
    double h = MediaQuery.of(context).size.height;
    double w = MediaQuery.of(context).size.width;
    return Scaffold(
      body: Column(
        children: [
          Container(
            height: h*0.3,
            decoration: BoxDecoration(
              color:  Colors.black,
              image: DecorationImage(
                image: AssetImage("assets/images/fitmate.jpeg"),
                fit: BoxFit.fill,
              ),
              
            ),
             ),
          
          Container(
            // color: Colors.amber,
            height: 300,
            child: ListView(
              children: [
                Container(
                  //child: Image(image: AssetImage("images/bicepcurls.jpg")),
                )
              //   ListTile(
              //     title: Text("Bicep curls"),
              //     leading : CircleAvatar(backgroundImage: AssetImage("assets/images/bicepcurls.jpg"),),
              //     tileColor: Colors.white,
              //   ),
              //   SizedBox(
              //   width: 20.0,
              //   height: 30.0,
              //  ),
              //   ListTile(
              //     title: Text("Lats Pull Down"),
              //     tileColor: Colors.white,
              //   ),
              ],
            ),
          )
        ],
      ),
    );
  }
}