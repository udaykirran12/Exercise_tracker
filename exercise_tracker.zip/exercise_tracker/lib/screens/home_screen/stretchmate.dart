import 'package:flutter/material.dart';
class StretchMate extends StatefulWidget {
  StretchMate({Key? key}) : super(key: key);

  @override
  State<StretchMate> createState() => _StretchMateState();
}

class _StretchMateState extends State<StretchMate> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color(0xFFD2FFF4),
    );
  }
}